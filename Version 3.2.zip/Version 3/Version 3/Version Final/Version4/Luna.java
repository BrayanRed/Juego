import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class Luna here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Luna extends Actor
{
    public Luna(){
    getImage().scale(getImage().getWidth()*2,getImage().getHeight()*2);
    }
    public void act()
    {
         if (Greenfoot.isKeyDown("right")){
            move(1);}
            if (Greenfoot.isKeyDown("d")){
            move(1);}
            if (Greenfoot.isKeyDown("left")){
            move(-1);}
            if (Greenfoot.isKeyDown("a")){
            move(-1);}
    } 
}
