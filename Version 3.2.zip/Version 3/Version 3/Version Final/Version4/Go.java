import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class Go here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Go extends Actor
{
    public Go(){
        getImage().scale(getImage().getWidth()*3,getImage().getHeight()*3);
    }
    public void act()
    {
        // Add your action code here.
    }
}
