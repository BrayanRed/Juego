import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class World2 here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class World2 extends World
{
    public GreenfootSound sounds = new GreenfootSound("Wordl2.mp3"); 
    public static int coins=10;
    public World2()
    {    
        super(7000,650, 1); 
        getBackground().setColor(new Color(135,206,235));//Dar color al fondo
        getBackground().fill();//Dar color al fondo
        prepare();
        play();
        act();
    }
    public void play() 
    {
        sounds.play();
    }
    
    public void act()
    {
       showText("Coins: "+ coins,50,25);
       if (!getObjects(GameOver.class).isEmpty())
        {
            sounds.stop();
            Greenfoot.stop(); 
        };
    }
    
    /**
     * Prepare the world for the start of the program.
     * That is: create the initial objects and add them to the world.
     */
    private void prepare()
    {
        coins=0;
        Ground ground = new Ground();
        addObject(ground,273,605);
        Ground ground2 = new Ground();
        addObject(ground2,848,496);
        Ground ground3 = new Ground();
        addObject(ground3,1435,606);
        Ground ground4 = new Ground();
        addObject(ground4,2161,601);
        ground4.setLocation(1960,616);
        ground4.setLocation(2155,608);
        ground4.setLocation(2295,596);
        ground4.setLocation(2298,616);
        Ground ground5 = new Ground();
        addObject(ground5,3101,604);
        Ground ground6 = new Ground();
        addObject(ground6,3791,605);
        Ground ground7 = new Ground();
        addObject(ground7,4923,605);
        Ground ground8 = new Ground();
        addObject(ground8,5934,603);
        Ground ground9 = new Ground();
        addObject(ground9,6716,315);
        GroundMid groundMid = new GroundMid();
        addObject(groundMid,367,349);
        GroundMid groundMid2 = new GroundMid();
        addObject(groundMid2,1463,383);
        GroundMid groundMid3 = new GroundMid();
        addObject(groundMid3,2698,468);
        GroundMid groundMid4 = new GroundMid();
        addObject(groundMid4,4537,219);
        GroundHigh groundHigh = new GroundHigh();
        addObject(groundHigh,1864,468);
        groundHigh.setLocation(1864,469);
        GroundHigh groundHigh2 = new GroundHigh();
        addObject(groundHigh2,2076,468);
        GroundHigh groundHigh3 = new GroundHigh();
        addObject(groundHigh3,3444,485);
        GroundHigh groundHigh4 = new GroundHigh();
        addObject(groundHigh4,3996,466);
        GroundHigh groundHigh5 = new GroundHigh();
        addObject(groundHigh5,4131,354);
        GroundHigh groundHigh6 = new GroundHigh();
        addObject(groundHigh6,3941,223);
        GroundHigh groundHigh7 = new GroundHigh();
        addObject(groundHigh7,4120,105);
        GroundHigh groundHigh8 = new GroundHigh();
        addObject(groundHigh8,5311,508);
        GroundHigh groundHigh9 = new GroundHigh();
        addObject(groundHigh9,5515,439);
        GroundHigh groundHigh10 = new GroundHigh();
        addObject(groundHigh10,5731,489);
        GroundHigh groundHigh11 = new GroundHigh();
        addObject(groundHigh11,6234,490);
        GroundHigh groundHigh12 = new GroundHigh();
        addObject(groundHigh12,6327,377);
        Brayan brayan = new Brayan();
        addObject(brayan,476,186);
        brayan.setLocation(424,253);
        brayan.setLocation(428,268);
        Brayan brayan2 = new Brayan();
        addObject(brayan2,1456,448);
        brayan2.setLocation(1443,528);
        Brayan brayan3 = new Brayan();
        addObject(brayan3,2113,348);
        brayan3.setLocation(2099,408);
        brayan3.setLocation(2094,388);
        Brayan brayan4 = new Brayan();
        addObject(brayan4,3152,492);
        brayan4.setLocation(3159,533);
        brayan4.setLocation(3158,521);
        Brayan brayan5 = new Brayan();
        addObject(brayan5,4244,273);
        brayan5.setLocation(4138,280);
        Brayan brayan6 = new Brayan();
        addObject(brayan6,5637,355);
        brayan6.setLocation(5564,370);
        brayan6.setLocation(5571,377);
        Brayan brayan7 = new Brayan();
        addObject(brayan7,6741,262);
        brayan7.setLocation(6742,227);
        Coin coin = new Coin();
        addObject(coin,340,272);
        Coin coin2 = new Coin();
        addObject(coin2,493,529);
        Coin coin3 = new Coin();
        addObject(coin3,1654,308);
        Coin coin4 = new Coin();
        addObject(coin4,2891,396);
        Coin coin5 = new Coin();
        addObject(coin5,3215,529);
        Coin coin6 = new Coin();
        addObject(coin6,3945,149);
        Coin coin7 = new Coin();
        addObject(coin7,4616,143);
        Coin coin8 = new Coin();
        addObject(coin8,5318,435);
        Coin coin9 = new Coin();
        addObject(coin9,5980,523);
        Coin coin10 = new Coin();
        addObject(coin10,6657,236);
        Player player = new Player();
        addObject(player,44,479);
        SecretDoor secretDoor= new SecretDoor();
        addObject(secretDoor, 6917, 125);
    }
}
