import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class Brayan here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Brayan extends Actor
{
int speed = 3;
    int count =0;
    int vida = 3;
    boolean  hitProyectil = false;
    public Brayan(){
       
        getImage().mirrorHorizontally();
        //Cambiar tamaño a objeto jugar
       GreenfootImage myImage = getImage();
       int myNewHeight = (int)myImage.getHeight()/8;
       int myNewWidth = (int)myImage.getWidth()/8;
       myImage.scale(myNewWidth, myNewHeight);
       // Terminar de cambiar tamaño de objeto
    }
    public void act()
    {
        count++;
        moveAround();
        hitByProyectil();
    }
    
    public void moveAround(){//Se mueve automaticamente
         
        if(count <60){
        setLocation(getX() + speed,getY());}
        else{
        speed = -speed;
        getImage().mirrorHorizontally();
        count = 0;
    }
    }
    public void hitByProyectil()
    {
         
        Actor proyectil = getOneIntersectingObject(Proyectil.class);
            if(proyectil != null && !hitProyectil){
                vida--;
                hitProyectil = true;
                getWorld().removeObject(proyectil);
            }
            else if(!isTouching(Proyectil.class))
            {
                hitProyectil = false;
            }
            if (vida <= 0)
            {
                getWorld().removeObject(this);
            }
    }
}
