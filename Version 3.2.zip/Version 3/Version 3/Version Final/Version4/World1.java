    import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class World1 here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class World1 extends World 
{
    public GreenfootSound sounds = new GreenfootSound("World1.mp3");
    public static int coins= 0;
    public World1()
    {    
        // Create a new world with 600x400 cells with a cell size of 1x1 pixels.
        super(7000, 650, 1);   
        prepare();
        play();
        act();
    }
    public void play() 
    {
        sounds.play();
    }
    
    public void act()
    {
       showText("Coins: "+ coins,50,25);
       if (!getObjects(GameOver.class).isEmpty())
        {
            sounds.stop(); 
            Greenfoot.stop(); 
        };
    }
    /**
     * Prepare the world for the start of the program.
     * That is: create the initial objects and add them to the world.
     */
    private void prepare()
    {
 
        coins=0;
        
        Luna luna = new Luna();
        addObject(luna,653,272);
        
        Ground ground = new Ground();
        addObject(ground,276,604);
        Ground ground2 = new Ground();
        addObject(ground2,839,603);
        Ground ground3 = new Ground();
        addObject(ground3,1824,603);
        Ground ground4 = new Ground();
        addObject(ground4,2840,604);
        Ground ground5 = new Ground();
        addObject(ground5,3397,604);
        ground5.setLocation(3397,604);
        Ground ground6 = new Ground();
        addObject(ground6,4496,597);
        ground6.setLocation(4506,608);
        Ground ground7 = new Ground();
        addObject(ground7,5727,603);
        ground7.setLocation(5747,616);
        GroundHigh groundHigh = new GroundHigh();
        addObject(groundHigh,1282,468);
        GroundHigh groundHigh2 = new GroundHigh();
        addObject(groundHigh2,2260,459);
        GroundHigh groundHigh3 = new GroundHigh();
        addObject(groundHigh3,2535,455);
        GroundHigh groundHigh4 = new GroundHigh();
        addObject(groundHigh4,3901,561);
        GroundHigh groundHigh5 = new GroundHigh();
        addObject(groundHigh5,4113,440);
        GroundHigh groundHigh6 = new GroundHigh();
        addObject(groundHigh6,4310,312);
        GroundHigh groundHigh7 = new GroundHigh();
        addObject(groundHigh7,4927,487);
        GroundHigh groundHigh8 = new GroundHigh();
        addObject(groundHigh8,5186,364);
        GroundHigh groundHigh9 = new GroundHigh();
        addObject(groundHigh9,5435,443);
        groundHigh8.setLocation(5160,389);
        groundHigh9.setLocation(5374,434);
        GroundHigh groundHigh10 = new GroundHigh();
        addObject(groundHigh10,6234,481);
        GroundHigh groundHigh11 = new GroundHigh();
        addObject(groundHigh11,6484,404);
        GroundHigh groundHigh20 = new GroundHigh();
        addObject(groundHigh20,6234,481);
        groundHigh20.setLocation(5991,508);
        groundHigh10.setLocation(6197,465);
        groundHigh11.setLocation(6424,418);
        GroundHigh groundHigh12 = new GroundHigh();
        addObject(groundHigh12,6685,315);
        groundHigh12.setLocation(6700,333);
        removeObject(groundHigh12);
        GroundHigh groundHigh13 = new GroundHigh();
        addObject(groundHigh13,1521,466);
        GroundMid groundMid = new GroundMid();
        addObject(groundMid,6743,286);
        GroundMid groundMid2 = new GroundMid();
        addObject(groundMid2,608,456);
        GroundMid groundMid3 = new GroundMid();
        addObject(groundMid3,961,309);
        GroundMid groundMid4 = new GroundMid();
        addObject(groundMid4,2868,320);
        groundMid4.setLocation(2784,339);
        groundMid4.setLocation(2796,332);
        GroundMid groundMid5 = new GroundMid();
        addObject(groundMid5,4653,187);
        GroundMid groundMid6 = new GroundMid();
        addObject(groundMid6,5693,306);
        groundMid6.setLocation(5584,281);
        groundMid6.setLocation(5600,270);
        Player player = new Player();
        addObject(player,69,462);
        Coin coin = new Coin();
        addObject(coin,523,376);
        Coin coin2 = new Coin();
        addObject(coin2,1520,393);
        Coin coin3 = new Coin();
        addObject(coin3,2901,257);
        Coin coin4 = new Coin();
        addObject(coin4,4276,240); 
        Coin coin5 = new Coin();
        addObject(coin5,4836,115);
        Coin coin6 = new Coin();
        addObject(coin6,5724,537);
        Coin coin7 = new Coin();
        addObject(coin7,5704,198);
        Coin coin8 = new Coin();
        addObject(coin8,6188,396);
        Coin coin9 = new Coin();
        addObject(coin9,1095,523);
        Coin coin10 = new Coin();
        addObject(coin10,6759,212);
        groundHigh2.setLocation(2416,446);
        groundHigh2.setLocation(2282,479);
        groundHigh3.setLocation(2228,530);
        groundHigh2.setLocation(2312,476);
        groundHigh2.setLocation(2465,408);
        groundHigh2.setLocation(2432,416);
        groundHigh2.setLocation(2372,411);
        groundHigh4.setLocation(3776,562);
        GroundHigh groundHigh14 = new GroundHigh();
        addObject(groundHigh14,3892,441);
        SecretDoor secretDoor= new SecretDoor();
        addObject(secretDoor, 6917, 125);
    }
    
    }
 
    

