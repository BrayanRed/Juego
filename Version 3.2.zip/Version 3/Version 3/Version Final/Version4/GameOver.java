import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class GameOver here.
 * 
 * @author (your name) 
 * @version (a version number or a date) 
 */
public class GameOver extends World
{
    private GreenfootSound sound = new GreenfootSound("Grito.mp3");
    /**
     * Constructor for objects of class GameOver.
     * 
     */ 
    public GameOver() 
    {    
        // Create a new world with 600x400 cells with a cell size of 1x1 pixels.
        super(1200, 650, 1); 
        prepare();
        play();  
    }
    /**
     * Prepare the world for the start of the program.
     * That is: create the initial objects and add them to the world.
     */
    private void prepare() 
    {
        Go go = new Go();
        addObject(go,580,344);
        go.setLocation(640,329);
    }
    public void play(){
        sound.play(); 
    }
}
