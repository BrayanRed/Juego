import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class Proyectil here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Proyectil extends Actor
{
     int speed = 10;
    
    public Proyectil(){
       getImage().scale(10,10);
    
    }
    public void act()
    {
        turnToMouse();
        move(speed);
        
    }
    public void turnToMouse(){//la bolita sigue el puntero del mouse
        //turnTowards(Greenfoot.getMouseInfo().getX(),Greenfoot.getMouseInfo().getY());
    }
}
