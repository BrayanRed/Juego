import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class Menu here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Menu extends World
{   private GreenfootSound sound = new GreenfootSound("Menu.mp3");
    private int opcion=0;// 0= jugar 1=opciones  2=salir
    Flecha miFlecha= new Flecha ();// Crea objeto flecha para interactuar con ella
    
    public Menu()
    {    
        
        super(1200, 650, 1); 
        prepare();
        play(); 
    }
    public void play(){
        sound.play();
    }
    /**
     * Prepare the world for the start of the program.
     * That is: create the initial objects and add them to the world.
     */
    private void prepare()
    {
        addObject(miFlecha,570,299);
        addObject(new Logo(),250,256);
        addObject(new Start(),690,300);
        addObject(new Opciones(),690,400);
        addObject(new Salir(),690,500);
        
    }
    public void act()
    {
        if(Greenfoot.isKeyDown("Up") && opcion!=0){
         opcion++;
        }//configurar flecha
        if(Greenfoot.isKeyDown("Down") && opcion!=1){
        opcion--;
        }
        if(Greenfoot.isKeyDown("Left") && opcion!=2){
        opcion--;
        }

        if(opcion>=3) opcion=0;//para que no se decrementen o aumenten valores en la opcion
        if(opcion<0) opcion=2;

        miFlecha.setLocation(570,300 +(opcion*100));

        if(Greenfoot.isKeyDown("ENTER"))
        {
            switch(opcion)
            {
                case 0:
                    Greenfoot.playSound("Menuflecha.mp3");
                    Greenfoot.setWorld(new World1());
                    sound.stop();
                    break;
                case 1:
                    Greenfoot.playSound("Menuflecha.mp3");
                    Greenfoot.setWorld(new Options());
                    sound.stop();
                    break;
                case 2:
                    Greenfoot.stop();
                    break;
            }
        }

    }
}
