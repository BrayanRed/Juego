import greenfoot.*;
 // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class Player here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Player extends Actor{   
    private int jeda =10,num=0,deltax=30;
    private GreenfootImage[] images=new GreenfootImage[5];
    private int vSpeed = 0;
    private int acceleration = 1;
    private int jumpHeight= -18;
    public int collect = 0;
    boolean  TenCoinsCollected = false;
    World1 thisGame;
    private void fall(){//Cambia posicion en y acorde a la vSpeed
       setLocation(getX(),getY()+vSpeed);
       vSpeed =vSpeed + acceleration; 
    }
    public void act()
    {
      moveAround(); 
      checkFalling();
      collect();
      SecondLevel();
      gameOver();
      fireProyectil();  
      hitMe(); 
    }
    public void addedToWorld(World MyWorld){//Agrega las imagenes de 0 a 4
        for(int i=0; i<images.length;i++){
            images[i]=new GreenfootImage("walk "+i+".png");
        }
        setImage(images[0]);
    }
    public void moveAround()
    {//mover
         if(Greenfoot.isKeyDown("right"))
         {//Se mueve con la animacion
            if(jeda==0)jeda=10;
             
            if(jeda==1)
            {
                setImage(images[num]);
                num++;
                if(num>=images.length)num=0;
                setLocation(getX()+deltax,getY());
                if(getX()>getWorld().getWidth()+100)setLocation(-100,getY());
            }
            if(jeda>0)jeda--;
        }
        
         if(Greenfoot.isKeyDown("d"))
         {//Se mueve con la animacion
            if(jeda==0)jeda=10;
            
            if(jeda==1)
            {
                setImage(images[num]);
                num++; 
                if(num>=images.length)num=0;
                setLocation(getX()+deltax,getY());
                if(getX()>getWorld().getWidth()+100)setLocation(-100,getY());
            }
            if(jeda>0)jeda--;
        }
                
        if(Greenfoot.isKeyDown("down"))
            {//AUMENTO DE VELOCIDAD AL CAMINAR
                if(jeda==10)jeda=0;
                if(jeda==1)
                {
                    setImage(images[num]);
                    num++;
                    if(num>=images.length)num=0;
                    setLocation(getX()+deltax,getY());
                    if(getX()>getWorld().getWidth()+100)setLocation(-100,getY());
                }
                if(jeda>9)jeda++;
        }//Termina
        
        if(Greenfoot.isKeyDown("s"))
            {//AUMENTO DE VELOCIDAD AL CAMINAR
                if(jeda==10)jeda=0;
                if(jeda==1)
                {
                    setImage(images[num]);
                    num++;
                    if(num>=images.length)num=0;
                    setLocation(getX()+deltax,getY());
                    if(getX()>getWorld().getWidth()+100)setLocation(-100,getY());
                }
                if(jeda>9)jeda++;
        }//Termina
                
                if(Greenfoot.isKeyDown("left"))
                {
                    move(-2);
                }
                
                if(Greenfoot.isKeyDown("a"))
                {
                    move(-2);
                }
                    
        //saltar
           if (Greenfoot.isKeyDown("up")&&(onGround()==true))
           {
             vSpeed= jumpHeight;
             fall();
           }
           if (Greenfoot.isKeyDown("up")&&(onGround2()==true))
           {
               vSpeed= jumpHeight;
               fall();
           }
           if (Greenfoot.isKeyDown("up")&&(onGround3()==true))
           {
               vSpeed= jumpHeight;
               fall();
           }
           if (Greenfoot.isKeyDown("w")&&(onGround()==true))
           {
               vSpeed= jumpHeight;
               fall();
           }
           if (Greenfoot.isKeyDown("w")&&(onGround2()==true))
           {
               vSpeed= jumpHeight;
               fall();
           }
           if (Greenfoot.isKeyDown("w")&&(onGround3()==true))
           {
               vSpeed= jumpHeight;
               fall();
           }
    }
    private boolean onGround(){//detectar suelo,cae completamente
         Actor under1 = getOneObjectAtOffset(0,getImage().getHeight()/2,Ground.class);
         return under1!= null;}
    boolean onGround2(){
       Actor under2 = getOneObjectAtOffset(0,getImage().getHeight()/2,GroundMid.class);
       return under2 != null;}
       boolean onGround3(){
       Actor under3 = getOneObjectAtOffset(0,getImage().getHeight()/2,GroundHigh.class);
       return under3!= null;
    }
    public void checkFalling(){//check caida
         if(onGround()== false || onGround2()==false || onGround3()==false){
            fall();
            }
            if(onGround()== true||onGround2()==true || onGround3()==true){
            vSpeed = 0;
            } 
    }
    
    public void collect(){//desaparece coin cuando player lo toca
       
        Actor coin = getOneIntersectingObject(Coin.class);//remueve
        if(coin != null){
            getWorld().removeObject(coin);
            thisGame.coins++;
        }
        if(collect==10 && TenCoinsCollected== false){//cuando el numero de coins llegue a 10, el juego para
            //Al tener 10 coins aparece una puerta
            TenCoinsCollected = true;
        }
     
    }
    public void SecondLevel(){
        Actor SecretDoor = getOneIntersectingObject(Coin.class);//Cuando se tocan 10 coin, aparece una puerta y al tocarla accede a otro mundo
          if (isTouching(SecretDoor.class))
          {
            Greenfoot.setWorld(new World2());
            ((World1)getWorld()).sounds.stop();
          }
    
    }
    public void gameOver() 
    {
       if (getY()==649)
       {
        Greenfoot.playSound("Grito.mp3");
        Greenfoot.setWorld(new GameOver());  
        ((World1)getWorld()).sounds.stop(); 
        ((World2)getWorld()).sounds.stop();
        }
    }
    public void fireProyectil(){//Agrega bolitas cuando doy click con el mouse
        
    if(Greenfoot.mousePressed(null))
    {
        Proyectil proyectil= new Proyectil(); 
        getWorld().addObject(proyectil,getX(),getY()); 
        proyectil.turnTowards(Greenfoot.getMouseInfo().getX(),Greenfoot.getMouseInfo().getY());
    }
    }
    public void hitMe(){
       if(isTouching(Brayan.class))
       {
           Greenfoot.setWorld(new GameOver());
       }
    }

}
    


