import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class Options here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Options extends Menu
{

    /**
     * Constructor for objects of class Options.
     * 
     */
    public Options()
    {
    }
}
